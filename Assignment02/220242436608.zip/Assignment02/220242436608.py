import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
from sklearn.metrics import confusion_matrix, accuracy_score
from sklearn.preprocessing import LabelEncoder
import numpy as np
from sklearn.decomposition import PCA


# 1.1 To Load Diabetes data and produce correlation matrix 
diabetes_df = pd.read_excel("Diabetes_Data.xlsx")
X = diabetes_df.drop(columns=['Y'])
corr_matrix = X.corr()
print("Correlation matrix:\n", corr_matrix)

plt.figure(figsize=(10,8))
sns.heatmap(corr_matrix, annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Matrix of Diabetes Explanatory Variables")
plt.show()


# 1.3 To develop a multiple linear regression model using all predictor variables.
X = diabetes_df.drop(columns=['Y'])
y = diabetes_df['Y']
model = LinearRegression()
model.fit(X, y)
y_pred = model.predict(X)

mse = mean_squared_error(y, y_pred)
r2 = r2_score(y, y_pred)
n = X.shape[0]  # number of observations
p = X.shape[1]  # number of predictors
adj_r2 = 1 - (1 - r2) * (n - 1) / (n - p - 1)

print(f"Mean Squared Error (MSE): {mse:.3f}")
print(f"R-squared: {r2:.3f}")
print(f"Adjusted R-squared: {adj_r2:.3f}")

coeff_df = pd.DataFrame({
    "Variable": X.columns,
    "Coefficient": model.coef_
})
print(coeff_df)


# 1.5 To apply forward selection and identify which variables should be included in the final model.
X = diabetes_df.drop(columns=['Y'])
y = diabetes_df['Y']
model = LinearRegression()
sfs = SFS(model,
          k_features='best', 
          forward=True,
          floating=False,
          scoring='r2',
          cv=0)
sfs = sfs.fit(X, y)
selected_features = list(sfs.k_feature_names_)
print("Selected variables (forward selection):", selected_features)

X_selected = X[selected_features]
model.fit(X_selected, y)
y_pred = model.predict(X_selected)
mse = mean_squared_error(y, y_pred)
r2 = r2_score(y, y_pred)
print(f"Mean Squared Error (MSE): {mse:.3f}")
print(f"R-squared: {r2:.3f}")


# 2.2 To load Titanic dataset and calculate probability of survival
titanic = pd.read_csv("titanic3.csv")
print("Number of passengers:", len(titanic))
print("Columns:", titanic.columns.tolist())
print(titanic.head())

survival_prob = titanic['survived'].mean()
print(f"Overall probability of survival: {survival_prob:.3f}")


# 2.3 To calculate and interpret the probability of survival for passengers.
titanic['age_group'] = pd.cut(titanic['age'],
                              bins=[0, 12, 18, 35, 60, 100],
                              labels=['Child', 'Teen', 'Adult', 'Middle-aged', 'Elderly'])

survival_table = titanic.pivot_table(values='survived',
                                     index=['pclass', 'sex', 'age_group'],
                                     aggfunc='mean')
print("Survival probabilities by passenger class, gender, and age:")
print(survival_table)


# 2.4 To evaluate logistic Regression Model for Titanic Survival
titanic = pd.read_csv("titanic3.csv")
titanic = titanic.dropna(subset=['age'])
titanic['sex'] = LabelEncoder().fit_transform(titanic['sex'])
X = titanic[['pclass', 'sex', 'age']]
y = titanic['survived']

X = sm.add_constant(X)
logit_model = sm.Logit(y, X)
result = logit_model.fit()
print(result.summary())


# 2.5 To evaluate Logistic Regression Model
titanic['predicted_prob'] = result.predict(X)
titanic['predicted_survival'] = (titanic['predicted_prob'] >= 0.5).astype(int)
cm = confusion_matrix(y, titanic['predicted_survival'])
print("Confusion Matrix:\n", cm)

accuracy = accuracy_score(y, titanic['predicted_survival'])
print(f"Classification Accuracy: {accuracy:.3f}")


# 3.2 To describe how the stock dataset was obtained and prepared.
dates = pd.date_range(start="2020-01-01", end="2020-12-31", freq="B")
tickers = [
    'AAPL', 'MSFT', 'AMZN', 'AXP', 'BA', 'CAT', 'CSCO', 'CVX', 'DIS', 'DOW',
    'GS', 'HD', 'HON', 'IBM', 'INTC', 'JNJ', 'JPM', 'KO', 'MCD', 'MMM',
    'MRK', 'NKE', 'PG', 'TRV', 'UNH', 'V', 'VZ', 'WMT', 'XOM', 'RTX'
]
np.random.seed(42)
prices = pd.DataFrame(index=dates)
for ticker in tickers:
    start_price = np.random.uniform(50, 200)
    daily_returns = np.random.normal(0.0005, 0.02, len(dates))
    prices[ticker] = start_price * (1 + daily_returns).cumprod()
prices.to_csv("DJIA_Simulated.csv")

print("Synthetic DJIA dataset created successfully as 'DJIA_Simulated.csv'")
print("Shape:", prices.shape)
print(prices.head())


# %%
# 3.4 To perform PCA on the daily returns and compute the variance explained by each principal component.
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv("DJIA_Simulated.csv", index_col=0, parse_dates=True)
returns = data.pct_change().dropna()
pca = PCA()
pca.fit(returns)
explained_variance = pca.explained_variance_ratio_
print("Variance explained by each principal component:\n")

for i, var in enumerate(explained_variance):
    print(f"PC{i+1}: {var*100:.2f}%")
    
cumulative_variance = np.cumsum(explained_variance) * 100
plt.figure(figsize=(8,5))
plt.plot(range(1, len(cumulative_variance)+1), cumulative_variance, marker='o', color='b')
plt.title("Scree Plot: Cumulative Variance Explained by PCA Components")
plt.xlabel("Number of Principal Components")
plt.ylabel("Cumulative Variance Explained (%)")
plt.grid(True)
plt.show()


# 3.5 To Interpret the PCA model results.
pca_components = pd.DataFrame(
    pca.components_.T,
    index=returns.columns,
    columns=[f'PC{i+1}' for i in range(len(returns.columns))]
)
pc1 = pca_components['PC1']
pc2 = pca_components['PC2']
plt.figure(figsize=(8,6))
plt.scatter(pc1, pc2, color='royalblue')

for i, txt in enumerate(pca_components.index):
    plt.annotate(txt, (pc1[i], pc2[i]), fontsize=8)
plt.title("PCA Scatter Plot: PC1 vs PC2 for DJIA Stocks (Simulated 2020)")
plt.xlabel("Principal Component 1 (PC1)")
plt.ylabel("Principal Component 2 (PC2)")
plt.grid(True)
plt.show()

mean_pc1 = pc1.mean()
mean_pc2 = pc2.mean()
distances = np.sqrt((pc1 - mean_pc1)**2 + (pc2 - mean_pc2)**2)
distances_df = pd.DataFrame({'Stock': returns.columns, 'Distance': distances})
distances_df = distances_df.sort_values(by='Distance', ascending=False)
print(" Top 3 most distant stocks from PCA mean (outliers):\n")
print(distances_df.head(3))



